@echo off
title CLUB+ - TEST_01
cd /d "%~dp0"
konsolowa.exe < dane_kontrolne.txt
echo.
pause
